package project2;

public enum BoardCell{
	GREENROBOT, REDROBOT, NONEBLACK, NONEWHITE, DEADROBOT
}

